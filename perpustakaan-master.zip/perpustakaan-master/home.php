<p></p>
<body>
    <center><font size="+7" face="arial">Sistem Informasi Perpustakaan</font></center>
    <center><img src="images/polines.jpg" alt=""></center>
</body>